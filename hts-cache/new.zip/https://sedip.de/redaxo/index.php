<!doctype html>
<html lang="de">
<head>
    <meta charset="utf-8" />

    <title>Login · SEDiP · REDAXO CMS</title>

    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link rel="stylesheet" type="text/css" media="all" href="index.php?asset=../assets/addons/be_style/css/styles.css&amp;buster=1606304020" />
    <link rel="stylesheet" type="text/css" media="all" href="index.php?asset=../assets/addons/be_style/css/bootstrap-select.min.css&amp;buster=1606303984" />
    <link rel="stylesheet" type="text/css" media="all" href="index.php?asset=../assets/addons/be_style/plugins/redaxo/css/styles.css&amp;buster=1606304020" />

    <script type="text/javascript">
    <!--
    var rex = {"backend":true,"accesskeys":true,"session_keep_alive":21600,"page":"login"};
    //-->
    </script>
    <script type="text/javascript" src="index.php?asset=../assets/core/jquery.min.js&amp;buster=1606304020" ></script>
    <script type="text/javascript" src="index.php?asset=../assets/core/jquery-ui.custom.min.js&amp;buster=1606304020" ></script>
    <script type="text/javascript" src="index.php?asset=../assets/core/jquery-pjax.min.js&amp;buster=1606304020" ></script>
    <script type="text/javascript" src="index.php?asset=../assets/core/standard.js&amp;buster=1606304020" ></script>
    <script type="text/javascript" src="index.php?asset=../assets/core/sha1.js&amp;buster=1606304020" ></script>
    <script type="text/javascript" src="index.php?asset=../assets/addons/be_style/javascripts/bootstrap.js&amp;buster=1606303984" ></script>
    <script type="text/javascript" src="index.php?asset=../assets/addons/be_style/javascripts/bootstrap-select.min.js&amp;buster=1606303984" ></script>
    <script type="text/javascript" src="index.php?asset=../assets/addons/be_style/javascripts/bootstrap-select-defaults-de_DE.min.js&amp;buster=1606303984" ></script>
    <script type="text/javascript" src="index.php?asset=../assets/addons/be_style/javascripts/main.js&amp;buster=1606304020" ></script>
    <script type="text/javascript" src="index.php?asset=../assets/addons/be_style/plugins/redaxo/javascripts/redaxo.js&amp;buster=1606304020" ></script>
    
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/addons/be_style/plugins/redaxo/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/addons/be_style/plugins/redaxo/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/addons/be_style/plugins/redaxo/icons/favicon-16x16.png">
    <link rel="manifest" href="../assets/addons/be_style/plugins/redaxo/icons/site.webmanifest">
    <link rel="mask-icon" href="../assets/addons/be_style/plugins/redaxo/icons/safari-pinned-tab.svg" color="#4d99d3">
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="theme-color" content="#4d99d3">
</head>
<body id="rex-page-login" onunload="closeAll();" class="rex-is-logged-out">

<div class="rex-ajax-loader" id="rex-js-ajax-loader">
    <div class="rex-ajax-loader-elements">
        <div class="rex-ajax-loader-element1 rex-ajax-loader-element"></div>
        <div class="rex-ajax-loader-element2 rex-ajax-loader-element"></div>
        <div class="rex-ajax-loader-element3 rex-ajax-loader-element"></div>
        <div class="rex-ajax-loader-element4 rex-ajax-loader-element"></div>
        <div class="rex-ajax-loader-element5 rex-ajax-loader-element"></div>
    </div>
</div>
<div id="rex-start-of-page" class="rex-page">

        <nav class="rex-nav-top navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                                            <a class="navbar-brand" href="index.php"><img class="rex-js-svg rex-redaxo-logo" src="../assets/core/redaxo-logo.svg" /></a>
                                                        </div>
                            </div>
        </nav>
<div id="rex-js-page-container" class="rex-page-container">
        <div class="rex-page-main"><section class="rex-page-main-inner" id="rex-js-page-main">
<header class="rex-page-header">
    <div class="page-header">
        <h1>Login                    </h1>
    </div>
    </header>

<form id="rex-form-login" action="index.php" method="post">
    <section class="rex-page-section">

    
            <div class="panel panel-default">
    
        <header class="panel-heading"><div class="panel-title">Bitte anmelden.</div></header>
        
                    <div class="panel-body">
                
    <fieldset>
        <input type="hidden" name="javascript" value="0" id="javascript" /><dl class="rex-form-group form-group rex-form-group-vertical"><dt><label for="rex-id-login-user">Benutzername:</label></dt><dd><div class="input-group"><span class="input-group-addon"><i class="rex-icon rex-icon-user"></i></span><input class="form-control" type="text" value="" id="rex-id-login-user" name="rex_user_login" autofocus /></div></dd></dl><dl class="rex-form-group form-group rex-form-group-vertical"><dt><label for="rex-id-login-password">Passwort:</label></dt><dd><div class="input-group"><span class="input-group-addon"><i class="rex-icon rex-icon-password"></i></span><input class="form-control" type="password" name="rex_user_psw" id="rex-id-login-password" /></div></dd></dl><dl class="rex-form-group form-group"><dd><div class="checkbox"><label for="rex-id-login-stay-logged-in"><input type="checkbox" name="rex_user_stay_logged_in" id="rex-id-login-stay-logged-in" value="1" />Eingeloggt bleiben</label></div></dd></dl></fieldset>            </div>
        
        
                    <footer class="panel-footer">
                                                    <div class="rex-form-panel-footer"><div class="btn-toolbar"><button class="btn btn-primary" type="submit"><i class="rex-icon rex-icon-sign-in"></i> Login </button></div></div>                            </footer>
        
            </div>


    </section>

    <input type="hidden" name="_csrf_token" value="uCoeKQT2CgmBmoRMx_ykhN9zoCNCuL3Djlf4kwgSgwA"/>
</form>
<script type="text/javascript">
     <!--
    jQuery(function($) {
        $("#rex-form-login")
            .submit(function(){
                var pwInp = $("#rex-id-login-password");
                if(pwInp.val() != "") {
                    $("#rex-form-login").append('<input type="hidden" name="'+pwInp.attr("name")+'" value="'+Sha1.hash(pwInp.val())+'" />');
                }
        });

        $("#javascript").val("1");
        
    });
     //-->
</script>
</section></div></div>    <footer class="rex-global-footer">
        <nav class="rex-nav-footer">
            <ul class="list-inline">
                <li><a href="#rex-start-of-page"><i class="fa fa-arrow-up"></i></a></li>
                <li><a href="https://www.yakamara.de" target="_blank" rel="noreferrer noopener">yakamara.de</a></li>
                <li><a href="https://www.redaxo.org" target="_blank" rel="noreferrer noopener">redaxo.org</a></li>
                                <li><a href="https://www.redaxo.org/" target="_blank" rel="noreferrer noopener">Credits</a></li>
                <li class="rex-js-script-time"><!--DYN-->0,038 Sek.<!--/DYN--></li>
            </ul>
        </nav>
    </footer>
</div><!-- END .rex-page -->
</body>
</html>
